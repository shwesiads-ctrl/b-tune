#!/usr/bin/env bash
set -euo pipefail
exec "$(dirname "$0")/build-macos.sh" arm64
