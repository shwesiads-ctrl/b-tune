import { useEffect, useRef, useState } from 'react';
import definitions from '../parameters.json';

type Meter = { pitch: number; input: number; output: number; progress: number };
type Session = { context: AudioContext; node: AudioWorkletNode; analyser: AnalyserNode; gain: GainNode; source?: AudioNode; stream?: MediaStream };
const tabs = ['Pitch Auto-Tune', 'Compressor', '5-Band EQ', 'Delay / Reverb'];
const choices = [
  ['C', 'C♯', 'D', 'D♯', 'E', 'F', 'F♯', 'G', 'G♯', 'A', 'A♯', 'B'],
  ['Chromatic', 'Major', 'Minor', 'Major Pentatonic', 'Minor Pentatonic'],
  ['Natural', 'Hard Tune']
];
const level = (v: number) => Math.max(-90, 20 * Math.log10(Math.max(1e-9, v))).toFixed(1);

export default function PluginUiWorkbench() {
  const [params, setParams] = useState(definitions.map(p => p.initial));
  const [tab, setTab] = useState(-1);
  const [sourceCode, setSourceCode] = useState('');
  const [meter, setMeter] = useState<Meter>({ pitch: 0, input: 0, output: 0, progress: 0 });
  const [status, setStatus] = useState('Choose a vocal file or microphone to begin.');
  const [active, setActive] = useState(false);
  const [busy, setBusy] = useState(false);
  const [analysing, setAnalysing] = useState(false);
  const [monitor, setMonitor] = useState(false);
  const [pitchHistory, setPitchHistory] = useState<number[]>([]);
  const session = useRef<Session | null>(null);
  const values = useRef(params);
  const scope = useRef<HTMLCanvasElement>(null);
  const eq = useRef<HTMLCanvasElement>(null);
  const file = useRef<HTMLInputElement>(null);
  const generation = useRef(0);
  const creating = useRef<AudioContext | null>(null);
  useEffect(() => { values.current = params; session.current?.node.port.postMessage({ params }); }, [params]);
  function change(i: number, value: number) {
    setParams(p => p.map((old, n) => n === i ? value : old));
  }
  async function stop() {
    generation.current++;
    const s = session.current; session.current = null;
    const pending = creating.current; creating.current = null;
    s?.stream?.getTracks().forEach(t => t.stop());
    s?.source?.disconnect(); s?.node.disconnect();
    s?.analyser.disconnect(); s?.gain.disconnect();
    if (s) s.node.port.onmessage = null;
    setActive(false); setBusy(false); setAnalysing(false); setMonitor(false);
    setMeter({ pitch: 0, input: 0, output: 0, progress: 0 });
    setPitchHistory([]); setStatus('Stopped.');
    // Capture and detach owned contexts before awaiting: a newer start may
    // create another context while these close operations are pending.
    await Promise.all([...new Set([s?.context, pending])].map(ctx =>
      ctx && ctx.state !== 'closed' ? ctx.close() : Promise.resolve()));
  }
  useEffect(() => () => {
    generation.current++;
    session.current?.stream?.getTracks().forEach(t => t.stop());
    void session.current?.context.close();
    void creating.current?.close();
  }, []);
  async function start(mode: 'mic' | 'file', audioFile?: File) {
    const stopped = stop(); const token = generation.current;
    setBusy(true); setStatus('Starting audio engine…');
    await stopped;
    if (token !== generation.current) return;
    let ctx: AudioContext | undefined; let stream: MediaStream | undefined;
    try {
      ctx = new AudioContext(); creating.current = ctx;
      await ctx.resume();
      if (token !== generation.current) return;
      const response = await fetch('/matale-dsp.wasm');
      if (!response.ok) throw new Error('DSP missing. Run scripts/build-web-dsp.sh first.');
      const module = await WebAssembly.compile(await response.arrayBuffer());
      if (token !== generation.current) return;
      await ctx.audioWorklet.addModule('/matale-worklet.js');
      if (token !== generation.current) return;
      const node = new AudioWorkletNode(ctx, 'matale', { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2], processorOptions: { module } });
      const analyser = ctx.createAnalyser(); analyser.fftSize = 2048;
      const gain = ctx.createGain(); gain.gain.value = mode === 'file' ? .7 : 0;
      node.connect(analyser); analyser.connect(gain); gain.connect(ctx.destination);
      let source: AudioNode;
      if (mode === 'mic') {
        stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
        if (token !== generation.current) return;
        source = ctx.createMediaStreamSource(stream);
      } else {
        if (!audioFile) throw new Error('Choose a vocal audio file.');
        const buffer = await ctx.decodeAudioData(await audioFile.arrayBuffer());
        if (token !== generation.current) return;
        const player = ctx.createBufferSource(); player.buffer = buffer; player.loop = true;
        source = player; player.start();
      }
      if (token !== generation.current) return;
      source.connect(node);
      session.current = { context: ctx, node, analyser, gain, source, stream }; creating.current = null;
      node.onprocessorerror = () => {
        if (session.current?.node !== node) return;
        void stop();
        setStatus('Audio processing failed. Start the input again to retry.');
      };
      node.port.onmessage = ({ data }) => {
        if (session.current?.node !== node) return;
        if ('autoResult' in data) {
          setAnalysing(false);
          if (data.autoResult) {
            setParams(old => { const next = [...old]; for (const [i, value] of data.autoResult) next[i] = value; return next; });
            setStatus('Auto applied. Key / scale preserved. Adjust to taste.');
          } else setStatus('Not enough voiced audio. Sing for three seconds and retry.');
        } else {
          setMeter(data);
          setPitchHistory(p => [...p.slice(-119), data.pitch]);
        }
      };
      node.port.postMessage({ params: values.current });
      setActive(true); setMonitor(mode === 'file');
      setStatus(mode === 'mic' ? 'Microphone live. Monitoring is muted; wear headphones before enabling.' : 'Vocal file looping. Audio stays in this browser.');
    } catch (err) {
      if (token === generation.current) setStatus(err instanceof Error ? err.message : 'Audio startup failed.');
    } finally {
      if (creating.current === ctx) creating.current = null;
      if (session.current?.context !== ctx) {
        stream?.getTracks().forEach(t => t.stop());
        if (ctx && ctx.state !== 'closed') await ctx.close();
      }
      if (token === generation.current) setBusy(false);
    }
  }

  useEffect(() => {
    let frame = 0; const data = new Float32Array(2048);
    const draw = () => {
      const canvas = scope.current, c = canvas?.getContext('2d');
      if (canvas && c) {
        c.clearRect(0, 0, canvas.width, canvas.height);
        c.strokeStyle = '#e3edf6'; c.beginPath(); c.moveTo(0, 80); c.lineTo(1000, 80); c.stroke();
        session.current?.analyser.getFloatTimeDomainData(data);
        if (!session.current) data.fill(0);
        c.strokeStyle = '#1685ff'; c.lineWidth = 1.5; c.beginPath();
        for (let i = 0; i < 1000; i++) { const y = 80 - data[i * 2] * 65; i ? c.lineTo(i, y) : c.moveTo(i, y); }
        c.stroke();
      }
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw); return () => cancelAnimationFrame(frame);
  }, []);
  useEffect(() => {
    const canvas = eq.current, c = canvas?.getContext('2d'); if (!canvas || !c) return;
    c.clearRect(0, 0, 1000, 150); c.strokeStyle = '#e3edf6'; c.beginPath(); c.moveTo(0, 75); c.lineTo(1000, 75); c.stroke();
    c.strokeStyle = '#1685ff'; c.lineWidth = 2; c.beginPath();
    const sr = session.current?.context.sampleRate ?? 48000;
    for (let x = 0; x < 1000; x++) {
      const f = 20 * Math.pow(1000, x / 999), w = 2 * Math.PI * f / sr;
      let dB = 0;
      for (let band = 0; band < 5; band++) {
        const base = 13 + band * 3, A = Math.pow(10, params[base + 1] / 40), w0 = 2 * Math.PI * Math.min(sr * .45, params[base]) / sr;
        const alpha = Math.sin(w0) / (2 * params[base + 2]), cos = Math.cos(w0);
        const mag = (a: number, b: number, d: number) => Math.hypot(a + b * Math.cos(w) + d * Math.cos(2 * w), -b * Math.sin(w) - d * Math.sin(2 * w));
        dB += 20 * Math.log10(mag(1 + alpha * A, -2 * cos, 1 - alpha * A) / mag(1 + alpha / A, -2 * cos, 1 - alpha / A));
      }
      const y = 75 - dB * 2; x ? c.lineTo(x, y) : c.moveTo(x, y);
    }
    c.stroke();
  }, [params, tab, active]);
  function valueText(i: number) {
    if (i === 28 || i === 31) return `${Math.round(params[i] * 100)}%`;
    const suffix = i === 7 || i === 5 ? '%' : i === 4 || i === 10 || i === 11 ? ' ms' : [8, 12, 14, 17, 20, 23, 26, 33].includes(i) ? ' dB' : '';
    return params[i].toFixed(definitions[i].step < 1 ? 1 : 0) + suffix;
  }
  function control(i: number, knob = false, title?: string) {
    const p = definitions[i], angle = -135 + 270 * (params[i] - p.lo) / (p.hi - p.lo);
    return <label className={knob ? 'control knob-control' : 'control'} key={p.id}>
      <span>{title ?? p.name}</span>
      {knob && <div className="knob" aria-hidden="true"><i style={{ transform: `rotate(${angle}deg)` }} /></div>}
      <strong>{valueText(i)}</strong>
      <input aria-label={p.name} type="range" min={p.lo} max={p.hi} step={p.step} value={params[i]} onChange={e => change(i, +e.target.value)} />
    </label>;
  }
  function selectors() {
    return <div className="selectors">{[0, 1, 2].map(i => <label key={i}>{definitions[i].name}
      <select value={params[i]} onChange={e => change(i, +e.target.value)}>
        {choices[i].map((s, n) => <option key={s} value={n}>{s}</option>)}
      </select></label>)}</div>;
  }
  const midi = meter.pitch > 0 ? Math.round(69 + 12 * Math.log2(meter.pitch / 440)) : null;
  const note = midi === null ? '—' : choices[0][((midi % 12) + 12) % 12] + (Math.floor(midi / 12) - 1);
  const points = pitchHistory.map((hz, i) => `${i * 8.3},${hz > 0 ? 100 - (69 + 12 * Math.log2(hz / 440) - 36) * 2 : 110}`).join(' ');
  const meterPercent = (v: number) => Math.max(0, Math.min(100, (Number(level(v)) + 60) / 60 * 100));
  return <main className="app-shell">
    <header className="app-header">
      <div className="brand"><b>M</b><div><h1>Matale Tune</h1><small>Pro Vocal Processor</small></div></div>
      <div className="header-right"><span className="tag">BROWSER WORKBENCH</span>
        <button className={'power ' + (params[3] ? 'on' : '')} aria-label="Toggle vocal processing" aria-pressed={!!params[3]} onClick={() => change(3, params[3] ? 0 : 1)}>
          <span className="dot" />{params[3] ? 'Processing on' : 'Bypassed'}</button></div>
    </header>
    <aside className="sidebar"><small>VOCAL TOOLS</small><nav aria-label="Vocal processors">
      {['Home', 'Pitch', 'Dynamics', 'EQ', 'Effects'].map((name, i) => <button key={name} aria-pressed={tab === i - 1} onClick={() => setTab(i - 1)}>
        <span aria-hidden="true">{['⌂', '〰', '≋', '☷', '✧'][i]}</span>{name}</button>)}
      </nav><div className="sidebar-foot"><span className={'dot ' + (active ? 'live' : '')} />{active ? 'Engine running' : 'Engine stopped'}<small>2048-frame DSP latency</small></div>
    </aside>
    <div className="workspace">
      <section className="toolbar" aria-label="Audio input">
        <div><b>Your voice. Your sound.</b><small>Choose a vocal file or microphone to begin.</small></div>
        <div className="input-actions"><button disabled={busy} onClick={() => file.current?.click()}>Vocal file</button>
          <input ref={file} type="file" accept="audio/*" hidden onChange={e => { const f = e.target.files?.[0]; if (f) void start('file', f); e.target.value = ''; }} />
          <button disabled={busy} onClick={() => void start('mic')}>Mic input</button>
          <button className="stop" disabled={!active && !busy} onClick={() => void stop()}>Stop</button>
        </div>
        <label className="monitor"><input type="checkbox" checked={monitor} disabled={!active} onChange={e => {
          setMonitor(e.target.checked); const s = session.current; if (s) s.gain.gain.setTargetAtTime(e.target.checked ? .7 : 0, s.context.currentTime, .02);
        }} /> Monitor · headphones</label>
      </section>
      <div className="analysis-grid">
        <section className="panel analysis"><div className="panel-heading"><h2><span>≋</span> Vocal Analysis</h2><span className={'live-pill ' + (active ? 'live' : '')}><i />{active ? 'Live' : 'Idle'}</span></div>
          <div className="analysis-body"><div className={'note-ring ' + (meter.pitch ? 'voiced' : '')}><strong>{note}</strong><small>{meter.pitch ? meter.pitch.toFixed(1) + ' Hz' : 'No voiced pitch'}</small></div>
            <div className="waveform"><div className="wave-label"><small>LIVE OUTPUT WAVEFORM</small><small>{session.current ? `${session.current.context.sampleRate / 1000} kHz` : 'Awaiting input'}</small></div>
              <canvas ref={scope} width="1000" height="160" aria-label="Live output waveform" />
              <div className="input-meter"><span>Input level</span><div className="meter-track"><i style={{ width: `${meterPercent(meter.input)}%` }} /></div><strong>{level(meter.input)} dBFS</strong></div>
            </div></div>
        </section>
        <section className="panel output"><h2><span>◖</span> Output</h2><div className="output-value">{level(meter.output)} <small>dBFS</small></div>
          <div className="meter-track"><i style={{ width: `${meterPercent(meter.output)}%` }} /></div>
          <div className="output-info"><span>PEAK LEVEL<small>Linked mono / stereo</small></span><span>{params[3] ? 'Processing on' : 'Bypassed'}<small>{active ? 'Audio engine active' : 'Start an input to listen'}</small></span></div>
        </section>
      </div>
      {tab === -1 ? <>
        <div className="home-grid"><section className="panel auto-panel"><div className="auto-description"><h2><span>✦</span> Auto Mode</h2><p>A starting point for your vocal. Fine-tune by ear.</p>
          <ul>{['Vocal input analysis', 'Dynamics & makeup', 'Retune & humanize', 'EQ recommendations', 'Reverb & delay'].map(s => <li key={s}><span>✓</span>{s}</li>)}</ul>
          <div className="auto-tip"><span>✧</span><div><b>Your key. Your scale.</b><small>Preserved when Auto is applied.</small></div></div></div>
          <div className="auto-action"><button className="auto-orb" aria-label="Set Audio On Auto" disabled={!active || analysing} onClick={() => { setAnalysing(true); setStatus('Listening for three seconds…'); session.current?.node.port.postMessage({ auto: true }); }}>
            <span>✦</span><b>{analysing ? 'LISTENING' : 'AUTO'}</b><small>{analysing ? `${Math.round(meter.progress * 100)}%` : '3 sec vocal analysis'}</small></button>
            <span className="auto-caption"><i className={'dot ' + (active ? 'live' : '')} />{analysing ? 'Sing for three seconds' : active ? 'Ready to analyse' : 'Start an input to enable Auto'}</span></div>
        </section>
        <section className="panel voice-settings"><h2><span>✧</span> Vocal Setup</h2><p>Set the musical target before you sing.</p>{selectors()}
          <button className="manual-button" onClick={() => setTab(0)}>Manual controls <span>→</span></button>
          <small>Use headphones for microphone monitoring.</small>
        </section></div>
        <section className="quick-rack" aria-label="Quick vocal controls">{[[7,'Pitch correction'],[4,'Retune speed'],[8,'Dynamics'],[6,'Formant colour'],[31,'Reverb'],[28,'Delay']].map(([i, name]) => control(Number(i), true, String(name)))}</section>
      </> : <section className="panel rack"><div className="panel-heading"><h2>{tabs[tab]}</h2><span className="tag">MANUAL CONTROLS</span></div>
        {tab === 0 && <>{selectors()}<svg viewBox="0 0 1000 120" role="img" aria-label="Detected pitch history"><polyline points={points} fill="none" stroke="#1685ff" strokeWidth="2" /></svg><small>Live pitch history · Formant is a dual-band colour filter.</small></>}
        {tab === 2 && <><canvas ref={eq} width="1000" height="150" aria-label="EQ response curve" /><small>20 Hz → 20 kHz · centre line 0 dB</small></>}
        <div className="rack-controls">{definitions.map((p, i) => p.page === tab && i > 3 ? control(i) : null)}</div>
      </section>}
      <footer role="status"><span className={active ? 'dot live' : 'dot'} />{status}{analysing && <progress value={meter.progress} max="1" />}</footer>
      <details><summary>Source, builds and tests</summary><p>Audio stays in your browser. This preview runs the shared C++ DSP through WebAssembly.</p>
        <p><a href="/MataleTune_Source.zip" download>Download source/build scripts</a> · <button onClick={async () => {
          try { const r = await fetch('/VocalDSP.h'); if (!r.ok) throw new Error('Source unavailable'); setSourceCode(await r.text()); }
          catch { setSourceCode('Source is in Source/VocalDSP.h in the package.'); }
        }}>Inspect C++ DSP</button></p>{sourceCode && <pre>{sourceCode}</pre>}
        <p>Browser validation comes first. Platform plugin builds require their target operating systems.</p></details>
    </div>
  </main>;
}
